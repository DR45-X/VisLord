from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from typing import Dict

app = FastAPI()
connected_users: Dict[str, WebSocket] = {}

@app.websocket("/ws/{username}")
async def websocket_endpoint(websocket: WebSocket, username: str):
    if username in connected_users:
        await websocket.close()
        return  # Reject duplicate names

    await websocket.accept()
    connected_users[username] = websocket

    try:
        while True:
            data = await websocket.receive_text()
            for user, conn in connected_users.items():
                if user != username:
                    await conn.send_text(f"{username}: {data}")
    except WebSocketDisconnect:
        del connected_users[username]

# Run with: uvicorn server:app --host 0.0.0.0 --port 8000
