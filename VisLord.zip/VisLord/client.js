const express = require("express");
const WebSocket = require("ws");

const app = express();
const port = 3000;

app.use(express.static("public")); // Serve HTML & JS files

const server = app.listen(port, () => {
  console.log(`Frontend running on http://localhost:${port}`);
});
